import { useEffect, useState } from 'react';
import { View, Text, Image } from 'react-native';
import axios from 'axios';

export default App = () => {
  const [data, setData] = useState([]); 

  useEffect(() => {
    axios
      .get('https://reqres.in/api/users?page=2')
      .then((res) => {setData(res.data.data)})
      .catch((err) => console.log('Error:', err));
  }, []); 

  return <View>
  {data.map((val) => <View>
    <Text>{val.first_name}</Text>
    <Image style={{width:200,height:200}} source={{uri: val.avatar}}/>
    <Text>{val.email}</Text>
  
  </View>)}
  
  </View>
}