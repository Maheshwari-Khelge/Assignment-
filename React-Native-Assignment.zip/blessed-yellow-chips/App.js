import { Text, View } from "react-native"
import Header from "./components/header"
import Main from "./components/Main.jsx";

export default App = () => {
  return <View>
    <Header/>
    <Main/>
  </View>
}