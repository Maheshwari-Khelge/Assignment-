import { Image, View ,Text} from "react-native"
export default Main = () => {
  return <View style={{display:"flex",flexDirection:"column",justifyContent:"space-around"}}>
  <View style={{display:"flex",flexDirection:"row"}}>
  <View>
  <Image style={{width:150,height:150,position:"relative",margin:5}} source={require('../assets/USA.jpg')}/>
  <Text style={{position:"absolute",color:"white",marginLeft:10,marginTop:130,fontWeight:"bold",}}>US East</Text>  
  </View>
  <View>
  <Image style={{width:150,height:150,position:"relative",margin:5}} source={require('../assets/img2.jpg')}/>
  <Text style={{position:"absolute",color:"white",marginLeft:10,marginTop:130,fontWeight:"bold"}}>US West</Text>  
  </View>
  </View>

 <View style={{display:"flex",flexDirection:"row"}}>
  <View>
  <Image style={{width:150,height:150,position:"relative",margin:5}} source={require('../assets/img3.jpg')}/>
  <Text style={{position:"absolute",color:"white",marginLeft:10,marginTop:130,fontWeight:"bold"}}>Hawali</Text>  
  </View>
  <View>
  <Image style={{width:150,height:150,position:"relative",margin:5}} source={require('../assets/img4.jpg')}/>
  <Text style={{position:"absolute",color:"white",marginLeft:10,marginTop:130,fontWeight:"bold"}}>Canada</Text> 
  </View>
</View>

  <View> 
  <Image style={{width:150,height:150,position:"relative",margin:5}} source={require('../assets/img5.jpg')}/>
  <Text style={{position:"absolute",color:"white",marginLeft:10,marginTop:130,fontWeight:"bold"}}>Austrelia</Text>  
  </View>
 

  </View>
}