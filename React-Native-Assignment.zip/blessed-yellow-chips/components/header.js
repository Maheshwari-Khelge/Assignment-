import { Image, View ,Text} from "react-native"

export default Header = () => {
  return <View style={{display:"flex",flexDirection:"row"}}>
    <Image style={{width:30,height:20}} source={require('../assets/loc.png')}/>
    <Text style={{marginLeft:200}}>Nearby Tours</Text>
  </View>
}