import { useReducer } from "react";

let App = () =>{
  let reducerFun = (state, action) => {
    switch (action.type) {
      case "CHANGE_FNAME":
        return { ...state, firstName: action.payload };
      case "CHANGE_LNAME":
        return { ...state, lastName: action.payload };
      case "CHANGE_EMAIL":
        return { ...state, Email: action.payload };
      case "CHANGE_PASS":
        return { ...state, Password: action.payload };
      default:
        return state;
    }
  };
let [store,Dispatch] = useReducer(reducerFun,{firstName :"",lastName:"",Email:"",Password :""})
    return <div className="mb-3" style={{width:"400px"}}>
        <label htmlFor="fname">First Name</label>
        <input type="text"  value={store.firstName} onChange={(evt) => Dispatch({type: "CHANGE_FNAME", payload: evt.target.value}) } className="form-control" id="fname"  />
        <br/>
        <label htmlFor="lname">Last Name</label>
        <input type="text" value={store.lastName} onChange={(evt) => Dispatch({type: "CHANGE_LNAME", payload: evt.target.value}) } className="form-control" id="lname" />
        <br/>
        <label htmlFor="mail">Email</label>
        <input type="text" value={store.Email} onChange={(evt) => Dispatch({type: "CHANGE_EMAIL", payload: evt.target.value}) } className="form-control" id="mail"/>
        <br/>
        <label htmlFor="pass">Password</label>
        <input type="text" value={store.Password} onChange={(evt) => Dispatch({type: "CHANGE_PASS", payload: evt.target.value}) } className="form-control" id="pass"/>
        <br/>
     
        <ol>
        <li>FirstName : {store.firstName}</li>
        <li>LastName : {store.lastName}</li>
        <li>Email : {store.Email}</li>
        <li>Password : {store.Password}</li>
        </ol>
    </div>
}
export default App;

