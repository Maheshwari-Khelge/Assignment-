import React, { useReducer } from "react";

let App = () =>{
  let reducerFun = (state, action) => {
    switch (action.type) {
      case "SET_VALUES":
        return { ...state, ...action.payload };
      default:
        return state;
    }
  };
let [store,Dispatch] = useReducer(reducerFun,{firstName :"",lastName:"",Email:"",Password :""})

let ipName = React.createRef();
let ipLname = React.createRef()
let ipEmail = React.createRef();
let ipPassword = React.createRef();

    return <div className="mb-3" style={{width:"400px"}}>
      <form    onSubmit={(evt) => {
          evt.preventDefault();
          Dispatch({
            type: "SET_VALUES",
            payload: {
              firstName: ipName.current.value,
              lastName: ipLname.current.value,
              Email: ipEmail.current.value,
              Password: ipPassword.current.value
            }
          });
        }}>
        <label htmlFor="fname">First Name</label>
        <input type="text"  ref={ipName} className="form-control" id="fname"  />
        <br/>
        <label htmlFor="lname">Last Name</label>
        <input type="text" ref={ipLname} className="form-control" id="lname" />
        <br/>
        <label htmlFor="mail">Email</label>
        <input type="text" ref={ipEmail} className="form-control" id="mail"/>
        <br/>
        <label htmlFor="pass">Password</label>
        <input type="text" ref={ipPassword} className="form-control" id="pass"/>
        <br/>
         <button type="submit"  className="btn btn-primary"  >Submit</button>
      
        <ol>
        <li>FirstName : {store.firstName}</li>
        <li>LastName : {store.lastName}</li>
        <li>Email : {store.Email}</li>
        <li>Password : {store.Password}</li>
        </ol>
        </form>
    </div>
}
export default App;

