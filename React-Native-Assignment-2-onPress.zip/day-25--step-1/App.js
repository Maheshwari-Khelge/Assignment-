import React, { useState } from 'react';
import { ScrollView, View, StyleSheet, TouchableWithoutFeedback } from 'react-native';
 
const styles = StyleSheet.create({
  box: { height: 200, marginBottom: 10 },
  firstBox: { marginTop: 50, backgroundColor: 'red' },
});
 
export default function App() {
  const [state, setState] = useState({width:"50%"});
 
  const handleBoxPress = () => {
    setState({width:"100%"});
  };
 
  return (
      <View>
        <TouchableWithoutFeedback onPress={() => {handleBoxPress()}}>
          <View style={[{...styles.box}, styles.firstBox,state]}></View>  
      </TouchableWithoutFeedback>
       
       </View>
  );
}