import { ScrollView, View } from "react-native"
import Header from "./components/header"
import Main from "./components/Main.jsx";

export default App = () => {
  return <ScrollView>
   <View>
    <Header/>
    <Main/>
  </View>
   </ScrollView>
}